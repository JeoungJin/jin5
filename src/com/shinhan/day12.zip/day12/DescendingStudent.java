package com.shinhan.day12;

import java.util.Comparator;

public class DescendingStudent implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
